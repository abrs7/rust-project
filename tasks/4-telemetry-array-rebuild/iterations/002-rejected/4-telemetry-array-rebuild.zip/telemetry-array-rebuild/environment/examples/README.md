# Worked experiments

Each JSON document pairs opaque hex with a recovered semantic object. The
pair is an empirical result from the lost laboratory benches. Layouts, byte
order, integrity algorithms, quoting, whitening, payload packing, tick wrap,
and calibration arithmetic are not restated here; recover them from the
examples and then apply the same laws to `/app/fragments`.

Negative examples are expected to be rejected by the corresponding stage.
Do not copy example hex into campaign products.
