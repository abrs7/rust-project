"""Synthetic telemetry recovery package."""
